module.exports = {
  googleClientID: process.env.GOOGLE_CLIENT_ID,
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET,
  mongoURI: "mongodb+srv://lomsianidzegiorgi123:KZJvU3OafHsdNtnw@cluster0.ljxslts.mongodb.net/?retryWrites=true&w=majority",
  cookieKey: process.env.COOKIE_KEY
};
