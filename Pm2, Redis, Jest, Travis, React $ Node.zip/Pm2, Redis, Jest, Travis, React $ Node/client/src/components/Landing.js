import React from 'react';

const Landing = () => {
  return (
    <div style={{ textAlign: 'center' }}>
      <h1>
        Blogster!
      </h1>
      Write private blogs
    </div>
  );
};

export default Landing;
